import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';

class FrameThirtysixScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              decoration: AppDecoration.fillWhiteA700,
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                        height: getVerticalSize(177),
                                        width: double.maxFinite,
                                        child: Stack(
                                            alignment: Alignment.bottomLeft,
                                            children: [
                                              Align(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  child: Container(
                                                      padding: getPadding(
                                                          left: 12,
                                                          top: 21,
                                                          right: 12,
                                                          bottom: 21),
                                                      decoration: AppDecoration
                                                          .gradientTeal900Lightblue50,
                                                      child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: [
                                                            CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgArrowleft,
                                                                height:
                                                                    getVerticalSize(
                                                                        25),
                                                                width:
                                                                    getHorizontalSize(
                                                                        26),
                                                                margin:
                                                                    getMargin(
                                                                        bottom:
                                                                            63),
                                                                onTap: () {
                                                                  onTapImgArrowleft(
                                                                      context);
                                                                })
                                                          ]))),
                                              Align(
                                                  alignment:
                                                      Alignment.bottomLeft,
                                                  child: Card(
                                                      clipBehavior:
                                                          Clip.antiAlias,
                                                      elevation: 0,
                                                      margin: EdgeInsets.all(0),
                                                      color: ColorConstant
                                                          .blueGray100,
                                                      shape: RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius.circular(
                                                                  getHorizontalSize(
                                                                      46))),
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  92),
                                                          width:
                                                              getHorizontalSize(
                                                                  91),
                                                          padding: getPadding(
                                                              left: 28,
                                                              top: 22,
                                                              right: 28,
                                                              bottom: 22),
                                                          decoration: AppDecoration
                                                              .fillBluegray100
                                                              .copyWith(
                                                                  borderRadius:
                                                                      BorderRadiusStyle
                                                                          .circleBorder46),
                                                          child:
                                                              Stack(children: [
                                                            CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgUser,
                                                                height:
                                                                    getVerticalSize(
                                                                        41),
                                                                width:
                                                                    getHorizontalSize(
                                                                        35),
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter)
                                                          ]))))
                                            ])),
                                    Padding(
                                        padding: getPadding(left: 46, top: 13),
                                        child: Text("MillieBrown431",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterBold23)),
                                    Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                            padding: getPadding(
                                                left: 11, top: 36, right: 12),
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Container(
                                                      width: getHorizontalSize(
                                                          169),
                                                      padding: getPadding(
                                                          left: 30,
                                                          top: 2,
                                                          right: 51,
                                                          bottom: 2),
                                                      decoration: AppDecoration
                                                          .txtOutlineBlack9003f
                                                          .copyWith(
                                                              borderRadius:
                                                                  BorderRadiusStyle
                                                                      .txtRoundedBorder16),
                                                      child: Text("Follow",
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular21)),
                                                  Container(
                                                      width: getHorizontalSize(
                                                          169),
                                                      padding: getPadding(
                                                          left: 30,
                                                          top: 1,
                                                          right: 38,
                                                          bottom: 1),
                                                      decoration: AppDecoration
                                                          .txtOutlineBlack9003f1
                                                          .copyWith(
                                                              borderRadius:
                                                                  BorderRadiusStyle
                                                                      .txtRoundedBorder16),
                                                      child: Text("Message",
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterRegular21))
                                                ]))),
                                    Container(
                                        width: getHorizontalSize(303),
                                        margin: getMargin(
                                            left: 27, top: 23, right: 59),
                                        child: RichText(
                                            text: TextSpan(children: [
                                              TextSpan(
                                                  text:
                                                      "Khayaban-e-Suhrwardy, Opposite Convention Centre,, Islamabad 44000Islamabad, ",
                                                  style: TextStyle(
                                                      color:
                                                          ColorConstant.gray800,
                                                      fontSize: getFontSize(14),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w400)),
                                              TextSpan(
                                                  text: "Pakistan",
                                                  style: TextStyle(
                                                      color:
                                                          ColorConstant.gray800,
                                                      fontSize: getFontSize(14),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      decoration: TextDecoration
                                                          .underline))
                                            ]),
                                            textAlign: TextAlign.left)),
                                    Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                            height: getVerticalSize(255),
                                            width: getHorizontalSize(353),
                                            margin:
                                                getMargin(top: 47, bottom: 194),
                                            child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Padding(
                                                          padding: getPadding(
                                                              left: 73,
                                                              right: 62),
                                                          child: Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .min,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                            211),
                                                                    margin: getMargin(
                                                                        left:
                                                                            5),
                                                                    padding: getPadding(
                                                                        left:
                                                                            36,
                                                                        right:
                                                                            36),
                                                                    decoration: AppDecoration
                                                                        .outlineBlack9001
                                                                        .copyWith(
                                                                            borderRadius: BorderRadiusStyle
                                                                                .roundedBorder3),
                                                                    child: Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize
                                                                                .min,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment
                                                                                .start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        children: [
                                                                          Padding(
                                                                              padding: getPadding(top: 3),
                                                                              child: Text("Organized Events", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterRegular15Black900))
                                                                        ])),
                                                                Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                            204),
                                                                    margin: getMargin(
                                                                        left: 1,
                                                                        top: 26,
                                                                        right:
                                                                            10),
                                                                    child: Text(
                                                                        "Digital Marketing Bootcamp\n• Conference • Researchfora",
                                                                        maxLines:
                                                                            null,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .center,
                                                                        style: AppStyle
                                                                            .txtInterRegular15Black9001)),
                                                                Container(
                                                                    width:
                                                                        getHorizontalSize(
                                                                            204),
                                                                    margin: getMargin(
                                                                        top: 47,
                                                                        right:
                                                                            12),
                                                                    child: Text(
                                                                        "Women in Tech Seminar\n• Conference • Researchfora",
                                                                        maxLines:
                                                                            null,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .center,
                                                                        style: AppStyle
                                                                            .txtInterRegular15Black9001))
                                                              ]))),
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  255),
                                                          width:
                                                              getHorizontalSize(
                                                                  353),
                                                          decoration: BoxDecoration(
                                                              border: Border.all(
                                                                  color: ColorConstant
                                                                      .gray500,
                                                                  width:
                                                                      getHorizontalSize(
                                                                          1)))))
                                                ])))
                                  ])))
                    ]))));
  }

  onTapImgArrowleft(BuildContext context) {
    Navigator.pop(context);
  }
}

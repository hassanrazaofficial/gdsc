import '../frame_twentythree_screen/widgets/listab_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:maryam_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class FrameTwentythreeScreen extends StatelessWidget {
  TextEditingController groupThirtyFourController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(306),
                          width: double.maxFinite,
                          child: Stack(alignment: Alignment.center, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgRectangle38,
                                height: getVerticalSize(305),
                                width: getHorizontalSize(390),
                                alignment: Alignment.center),
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    height: getVerticalSize(306),
                                    width: getHorizontalSize(389),
                                    child: Stack(
                                        alignment: Alignment.topLeft,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgMapofworldon,
                                              height: getVerticalSize(306),
                                              width: getHorizontalSize(389),
                                              alignment: Alignment.center),
                                          Align(
                                              alignment: Alignment.topLeft,
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 19, top: 52),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        CustomAppBar(
                                                            height:
                                                                getVerticalSize(
                                                                    46),
                                                            leadingWidth: 46,
                                                            leading: AppbarImage(
                                                                height:
                                                                    getVerticalSize(
                                                                        25),
                                                                width: getHorizontalSize(
                                                                    26),
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgArrowleft,
                                                                margin: getMargin(
                                                                    left: 20,
                                                                    top: 10,
                                                                    bottom: 11),
                                                                onTap: () =>
                                                                    onTapArrowleft(
                                                                        context)),
                                                            centerTitle: true,
                                                            title: CustomTextFormField(
                                                                width: getHorizontalSize(
                                                                    278),
                                                                focusNode:
                                                                    FocusNode(),
                                                                controller:
                                                                    groupThirtyFourController,
                                                                hintText:
                                                                    "Search",
                                                                variant:
                                                                    TextFormFieldVariant
                                                                        .FillGray20075,
                                                                shape: TextFormFieldShape
                                                                    .RoundedBorder7,
                                                                padding:
                                                                    TextFormFieldPadding
                                                                        .PaddingAll12,
                                                                fontStyle:
                                                                    TextFormFieldFontStyle
                                                                        .InterLight18,
                                                                textInputAction:
                                                                    TextInputAction
                                                                        .done)),
                                                        Container(
                                                            margin: getMargin(
                                                                left: 13,
                                                                top: 59),
                                                            padding: getPadding(
                                                                left: 14,
                                                                top: 10,
                                                                right: 14,
                                                                bottom: 10),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          bottom:
                                                                              2),
                                                                      child: Text(
                                                                          "AB",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtInterMedium20))
                                                                ]))
                                                      ])))
                                        ])))
                          ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          margin: getMargin(top: 232, bottom: 106),
                          padding: getPadding(
                              left: 12, top: 37, right: 12, bottom: 37),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder43),
                          child: ListView.separated(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              separatorBuilder: (context, index) {
                                return SizedBox(height: getVerticalSize(13));
                              },
                              itemCount: 3,
                              itemBuilder: (context, index) {
                                return ListabItemWidget(
                                    onTapTxtComputerliteracOne: () =>
                                        onTapTxtComputerliteracOne(context),
                                    onTapApply: () => onTapApply(context));
                              }))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          margin: getMargin(left: 20, top: 131, right: 12),
                          padding:
                              getPadding(left: 9, top: 8, right: 9, bottom: 8),
                          decoration: AppDecoration.outlineGray500.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder23),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                    padding:
                                        getPadding(left: 4, top: 3, right: 7),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          CustomButton(
                                              height: getVerticalSize(48),
                                              width: getHorizontalSize(56),
                                              text: "AB",
                                              margin: getMargin(top: 4),
                                              variant:
                                                  ButtonVariant.FillBluegray100,
                                              shape: ButtonShape.Square,
                                              fontStyle:
                                                  ButtonFontStyle.InterMedium20,
                                              onTap: () => onTapAbOne(context)),
                                          GestureDetector(
                                              onTap: () {
                                                onTapTxtEducationaloutrOne(
                                                    context);
                                              },
                                              child: Container(
                                                  width: getHorizontalSize(208),
                                                  margin: getMargin(left: 13),
                                                  child: Text(
                                                      "Educational Outreach Program",
                                                      maxLines: null,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterSemiBold20))),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgVideocamera,
                                              height: getSize(16),
                                              width: getSize(16),
                                              margin: getMargin(
                                                  left: 1,
                                                  top: 23,
                                                  bottom: 13)),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgFavorite,
                                              height: getVerticalSize(14),
                                              width: getHorizontalSize(16),
                                              margin: getMargin(
                                                  left: 16,
                                                  top: 24,
                                                  bottom: 13))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 73),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Container(
                                              width: getHorizontalSize(160),
                                              child: Text(
                                                  "Developments in Literacy, \nsupported by the UN Development Programme",
                                                  maxLines: null,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterMedium13)),
                                          CustomButton(
                                              height: getVerticalSize(40),
                                              width: getHorizontalSize(81),
                                              text: "Apply",
                                              margin: getMargin(
                                                  left: 23, top: 9, bottom: 1),
                                              variant: ButtonVariant
                                                  .OutlineBlack9003f,
                                              shape:
                                                  ButtonShape.RoundedBorder16,
                                              fontStyle: ButtonFontStyle
                                                  .InterRegular17,
                                              onTap: () => onTapApply(context))
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          margin: getMargin(
                              left: 20, top: 667, right: 12, bottom: 5),
                          padding: getPadding(
                              left: 9, top: 10, right: 9, bottom: 10),
                          decoration: AppDecoration.outlineGray5001.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder23),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomButton(
                                    height: getVerticalSize(48),
                                    width: getHorizontalSize(56),
                                    text: "AB",
                                    margin: getMargin(top: 4, bottom: 34),
                                    variant: ButtonVariant.FillBluegray100,
                                    shape: ButtonShape.Square,
                                    fontStyle: ButtonFontStyle.InterMedium20),
                                Container(
                                    height: getVerticalSize(80),
                                    width: getHorizontalSize(264),
                                    margin: getMargin(left: 8, top: 5),
                                    child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: [
                                          Align(
                                              alignment: Alignment.topLeft,
                                              child: GestureDetector(
                                                  onTap: () {
                                                    onTapTxtCodingbootcamp(
                                                        context);
                                                  },
                                                  child: Padding(
                                                      padding:
                                                          getPadding(left: 1),
                                                      child: Text(
                                                          "Coding Bootcamp",
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterSemiBold20Teal900)))),
                                          Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Container(
                                                  height: getVerticalSize(60),
                                                  width: getHorizontalSize(264),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topRight,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .centerLeft,
                                                            child: Container(
                                                                width:
                                                                    getHorizontalSize(
                                                                        199),
                                                                child: Text(
                                                                    "National University of Computer and Emerging Sciences, with support from Google",
                                                                    maxLines:
                                                                        null,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtInterMedium13))),
                                                        Align(
                                                            alignment: Alignment
                                                                .topRight,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        right:
                                                                            5),
                                                                child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .end,
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    children: [
                                                                      CustomImageView(
                                                                          svgPath: ImageConstant
                                                                              .imgVideocamera,
                                                                          height: getSize(
                                                                              16),
                                                                          width:
                                                                              getSize(16)),
                                                                      CustomImageView(
                                                                          svgPath: ImageConstant
                                                                              .imgFavorite,
                                                                          height: getVerticalSize(
                                                                              14),
                                                                          width: getHorizontalSize(
                                                                              16),
                                                                          margin: getMargin(
                                                                              left: 16,
                                                                              top: 1))
                                                                    ]))),
                                                        CustomButton(
                                                            height:
                                                                getVerticalSize(
                                                                    40),
                                                            width:
                                                                getHorizontalSize(
                                                                    81),
                                                            text: "Apply",
                                                            variant: ButtonVariant
                                                                .OutlineBlack9003f,
                                                            shape: ButtonShape
                                                                .RoundedBorder16,
                                                            fontStyle:
                                                                ButtonFontStyle
                                                                    .InterRegular17,
                                                            onTap: () =>
                                                                onTapApplyOne(
                                                                    context),
                                                            alignment: Alignment
                                                                .bottomRight)
                                                      ])))
                                        ]))
                              ])))
                ])),
            bottomNavigationBar: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: fs.Svg(ImageConstant.imgGroup30),
                        fit: BoxFit.cover)),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: double.maxFinite,
                              padding: getPadding(
                                  left: 33, top: 9, right: 33, bottom: 9),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: fs.Svg(ImageConstant.imgGroup30),
                                      fit: BoxFit.cover)),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                        svgPath: ImageConstant.imgEye,
                                        height: getSize(24),
                                        width: getSize(24),
                                        margin: getMargin(top: 35))
                                  ])))
                    ]))));
  }

  onTapTxtComputerliteracOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtyScreen);
  }

  onTapApply(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }

  onTapArrowleft(BuildContext context) {
    Navigator.pop(context);
  }

  onTapAbOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyfiveScreen);
  }

  onTapTxtEducationaloutrOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtyScreen);
  }

  onTapTxtCodingbootcamp(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtyScreen);
  }

  onTapApplyOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }
}

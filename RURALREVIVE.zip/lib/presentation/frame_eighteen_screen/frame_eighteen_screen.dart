import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FrameEighteenScreen extends StatelessWidget {
  TextEditingController socialmedialinksController = TextEditingController();

  TextEditingController interestsController = TextEditingController();

  TextEditingController occupationController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 15, right: 15),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                          padding: getPadding(top: 5),
                          child: Text("Set Your Profile",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold27)),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                              height: getVerticalSize(77),
                              width: getHorizontalSize(80),
                              margin: getMargin(left: 131, top: 42),
                              child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                            height: getVerticalSize(77),
                                            width: getHorizontalSize(80),
                                            decoration: BoxDecoration(
                                                color:
                                                    ColorConstant.blueGray100,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        getHorizontalSize(
                                                            40))))),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgSearch,
                                        height: getVerticalSize(35),
                                        width: getHorizontalSize(30),
                                        alignment: Alignment.topCenter,
                                        margin: getMargin(top: 18))
                                  ]))),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(left: 86, top: 21),
                              child: Text("Upload Profile Photo",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterLight18))),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: socialmedialinksController,
                          hintText: "Social Media Links ",
                          margin: getMargin(top: 53)),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: interestsController,
                          hintText: "Interests or Hobbies",
                          margin: getMargin(top: 20)),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: occupationController,
                          hintText: "Occupation or Field of Study",
                          margin: getMargin(top: 20),
                          textInputAction: TextInputAction.done),
                      Spacer(),
                      GestureDetector(
                          onTap: () {
                            onTapRowskip(context);
                          },
                          child: Padding(
                              padding: getPadding(left: 9, right: 19),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomButton(
                                        height: getVerticalSize(36),
                                        width: getHorizontalSize(70),
                                        text: "Skip",
                                        padding: ButtonPadding.PaddingAll8,
                                        fontStyle: ButtonFontStyle
                                            .InterRegular15Cyan900),
                                    CustomButton(
                                        height: getVerticalSize(36),
                                        width: getHorizontalSize(70),
                                        text: "Next",
                                        padding: ButtonPadding.PaddingAll8)
                                  ]))),
                      Container(
                          height: getVerticalSize(12),
                          width: getHorizontalSize(220),
                          margin: getMargin(top: 43),
                          decoration: BoxDecoration(
                              color: ColorConstant.cyan900,
                              borderRadius:
                                  BorderRadius.circular(getHorizontalSize(6))))
                    ]))));
  }

  onTapRowskip(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentythreeScreen);
  }
}

import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/core/utils/validation_functions.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FrameFiveScreen extends StatelessWidget {
  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 30, top: 69, right: 30),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                              width: getHorizontalSize(163),
                              margin: getMargin(left: 76),
                              child: Text("Rural Revive",
                                  maxLines: null,
                                  textAlign: TextAlign.center,
                                  style: AppStyle.txtSatisfyRegular61Teal900)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: emailController,
                              hintText: "Email",
                              margin: getMargin(left: 3, top: 28, right: 5),
                              variant: TextFormFieldVariant.FillGray100,
                              padding: TextFormFieldPadding.PaddingT16,
                              fontStyle:
                                  TextFormFieldFontStyle.InterLight18Gray50001,
                              textInputType: TextInputType.emailAddress),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: passwordController,
                              hintText: "Password",
                              margin: getMargin(left: 4, top: 35, right: 4),
                              variant: TextFormFieldVariant.FillGray100,
                              padding: TextFormFieldPadding.PaddingT16,
                              fontStyle:
                                  TextFormFieldFontStyle.InterLight18Gray50001,
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              isObscureText: true),
                          Align(
                              alignment: Alignment.center,
                              child: Padding(
                                  padding:
                                      getPadding(left: 26, top: 56, right: 19),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                            padding: getPadding(top: 1),
                                            child: Text("Forgot Password?",
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtKarlaRegular16
                                                    .copyWith(
                                                        decoration:
                                                            TextDecoration
                                                                .underline))),
                                        GestureDetector(
                                            onTap: () {
                                              onTapTxtOrcreateanaccouOne(
                                                  context);
                                            },
                                            child: Padding(
                                                padding: getPadding(
                                                    left: 2, bottom: 1),
                                                child: Text(
                                                    "Or Create an Account",
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtKarlaRegular16
                                                        .copyWith(
                                                            decoration:
                                                                TextDecoration
                                                                    .underline))))
                                      ]))),
                          Container(
                              height: getVerticalSize(19),
                              width: getHorizontalSize(17),
                              margin: getMargin(left: 142, top: 20),
                              child:
                                  Stack(alignment: Alignment.center, children: [
                                Align(
                                    alignment: Alignment.center,
                                    child: Text("Or",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtKarlaMedium16)),
                                Align(
                                    alignment: Alignment.center,
                                    child: Text("Or",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtKarlaMedium16))
                              ])),
                          Container(
                              margin: getMargin(top: 30, right: 8),
                              padding: getPadding(
                                  left: 45, top: 14, right: 45, bottom: 14),
                              decoration: AppDecoration.outlineGray40001,
                              child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgGoogle,
                                        height: getVerticalSize(31),
                                        width: getHorizontalSize(39)),
                                    Padding(
                                        padding: getPadding(
                                            left: 6,
                                            top: 7,
                                            right: 27,
                                            bottom: 4),
                                        child: Text("Continue with Google",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtKarlaMedium16Bluegray90001))
                                  ])),
                          Container(
                              margin: getMargin(
                                  left: 3, top: 22, right: 5, bottom: 5),
                              padding: getPadding(
                                  left: 42, top: 9, right: 42, bottom: 9),
                              decoration: AppDecoration.outlineGray40001,
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant
                                            .imgJshjwdremovebgpreview,
                                        height: getVerticalSize(31),
                                        width: getHorizontalSize(35),
                                        margin: getMargin(top: 10)),
                                    Padding(
                                        padding: getPadding(
                                            left: 8,
                                            top: 14,
                                            right: 14,
                                            bottom: 7),
                                        child: Text("Continue with Facebook",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtKarlaMedium16Bluegray90001))
                                  ]))
                        ])))));
  }

  onTapTxtOrcreateanaccouOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameFourteenScreen);
  }
}

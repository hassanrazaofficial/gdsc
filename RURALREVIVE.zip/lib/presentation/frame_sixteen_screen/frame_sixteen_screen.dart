import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/core/utils/validation_functions.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FrameSixteenScreen extends StatelessWidget {
  TextEditingController nameController = TextEditingController();

  TextEditingController websiteController = TextEditingController();

  TextEditingController descriptionController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 15, right: 15),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                              padding: getPadding(top: 5),
                              child: Text("Additional Information",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold27)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: nameController,
                              hintText: "Organization name",
                              margin: getMargin(top: 68)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: websiteController,
                              hintText: "Website (if applicable)",
                              margin: getMargin(top: 20)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: descriptionController,
                              hintText:
                                  "Description of your organization or company",
                              margin: getMargin(top: 20),
                              padding: TextFormFieldPadding.PaddingT47,
                              textInputAction: TextInputAction.done,
                              maxLines: 5),
                          Container(
                              width: double.maxFinite,
                              child: Container(
                                  width: getHorizontalSize(358),
                                  margin: getMargin(left: 1, top: 20, right: 1),
                                  padding: getPadding(
                                      left: 17, top: 15, right: 17, bottom: 15),
                                  decoration: AppDecoration.outlineGray5002
                                      .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.circleBorder6),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                            width: getHorizontalSize(253),
                                            margin:
                                                getMargin(right: 70, bottom: 2),
                                            child: Text(
                                                "Type of events you are interested in organizing",
                                                maxLines: null,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular15))
                                      ]))),
                          Container(
                              height: getVerticalSize(74),
                              width: getHorizontalSize(358),
                              margin: getMargin(top: 20),
                              child:
                                  Stack(alignment: Alignment.center, children: [
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                        width: getHorizontalSize(265),
                                        margin: getMargin(left: 17),
                                        child: Text(
                                            "Locations where you are interested in organizing events",
                                            maxLines: null,
                                            textAlign: TextAlign.left,
                                            style:
                                                AppStyle.txtInterRegular15))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        padding: getPadding(
                                            left: 17,
                                            top: 15,
                                            right: 17,
                                            bottom: 15),
                                        decoration: AppDecoration
                                            .outlineGray5002
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .circleBorder6),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                  width: getHorizontalSize(265),
                                                  margin: getMargin(
                                                      right: 58, bottom: 2),
                                                  child: Text(
                                                      "Locations where you are interested in organizing events",
                                                      maxLines: null,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterRegular15))
                                            ])))
                              ])),
                          Padding(
                              padding: getPadding(left: 9, top: 50, right: 19),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomButton(
                                        height: getVerticalSize(36),
                                        width: getHorizontalSize(70),
                                        text: "Back",
                                        padding: ButtonPadding.PaddingAll8),
                                    CustomButton(
                                        height: getVerticalSize(36),
                                        width: getHorizontalSize(70),
                                        text: "Next",
                                        padding: ButtonPadding.PaddingAll8,
                                        onTap: () => onTapNext(context))
                                  ])),
                          Padding(
                              padding: getPadding(top: 43),
                              child: Container(
                                  height: getVerticalSize(12),
                                  width: getHorizontalSize(220),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.blueGray100,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(6))),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(6)),
                                      child: LinearProgressIndicator(
                                          value: 0.5,
                                          backgroundColor:
                                              ColorConstant.blueGray100,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                                  ColorConstant.cyan900)))))
                        ])))));
  }

  onTapNext(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtyeightScreen);
  }
}

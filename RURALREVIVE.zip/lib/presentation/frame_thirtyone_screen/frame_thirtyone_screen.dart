import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';

class FrameThirtyoneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(306),
                          width: double.maxFinite,
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    height: getVerticalSize(306),
                                    width: double.maxFinite,
                                    decoration: BoxDecoration(
                                        color: ColorConstant.teal900))),
                            CustomImageView(
                                imagePath: ImageConstant.imgMapofworldon305x388,
                                height: getVerticalSize(305),
                                width: getHorizontalSize(388),
                                alignment: Alignment.center)
                          ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          margin: getMargin(bottom: 5),
                          padding: getPadding(
                              left: 20, top: 49, right: 20, bottom: 49),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder43),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    width: getHorizontalSize(233),
                                    child: Text("Response \nSubmitted!",
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtRobotoRomanBold47)),
                                CustomButton(
                                    height: getVerticalSize(36),
                                    width: getHorizontalSize(70),
                                    text: "Next",
                                    margin: getMargin(top: 86, bottom: 204),
                                    padding: ButtonPadding.PaddingAll8,
                                    onTap: () => onTapNext(context),
                                    alignment: Alignment.center)
                              ])))
                ]))));
  }

  onTapNext(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentythreeScreen);
  }
}

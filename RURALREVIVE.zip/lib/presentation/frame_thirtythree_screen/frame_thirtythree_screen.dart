import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';

class FrameThirtythreeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: double.maxFinite,
                        margin: getMargin(bottom: 5),
                        child: Stack(alignment: Alignment.topCenter, children: [
                          Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                  padding: getPadding(
                                      left: 85,
                                      top: 105,
                                      right: 85,
                                      bottom: 105),
                                  decoration: AppDecoration.fillTeal900,
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        CustomButton(
                                            height: getVerticalSize(49),
                                            text: "View More",
                                            margin: getMargin(top: 83),
                                            variant: ButtonVariant
                                                .OutlineBlack9003f_2,
                                            shape: ButtonShape.RoundedBorder16,
                                            padding: ButtonPadding.PaddingAll14,
                                            fontStyle:
                                                ButtonFontStyle.InterRegular17,
                                            onTap: () => onTapViewmore(context))
                                      ]))),
                          Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                  margin: getMargin(top: 5),
                                  padding: getPadding(
                                      left: 26, top: 72, right: 26, bottom: 72),
                                  decoration: AppDecoration.fillWhiteA700
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder43),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                            height: getVerticalSize(47),
                                            width: getHorizontalSize(337),
                                            margin: getMargin(top: 14),
                                            child: Stack(
                                                alignment: Alignment.centerLeft,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.centerRight,
                                                      child: GestureDetector(
                                                          onTap: () {
                                                            onTapTxtGroupNinetyOne(
                                                                context);
                                                          },
                                                          child: Container(
                                                              width:
                                                                  getHorizontalSize(
                                                                      191),
                                                              padding: getPadding(
                                                                  left: 28,
                                                                  top: 6,
                                                                  right: 28,
                                                                  bottom: 6),
                                                              decoration: AppDecoration
                                                                  .txtFillGray300b2
                                                                  .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .txtRoundedBorder8),
                                                              child: Text(
                                                                  "Upcomming",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtInterRegular21Black900)))),
                                                  CustomButton(
                                                      height:
                                                          getVerticalSize(47),
                                                      width: getHorizontalSize(
                                                          179),
                                                      text: "Recents",
                                                      variant: ButtonVariant
                                                          .FillCyan900,
                                                      fontStyle: ButtonFontStyle
                                                          .InterRegular21,
                                                      alignment:
                                                          Alignment.centerLeft)
                                                ])),
                                        Container(
                                            height: getVerticalSize(206),
                                            width: getHorizontalSize(336),
                                            margin: getMargin(top: 34),
                                            child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgRectangle50,
                                                      height:
                                                          getVerticalSize(206),
                                                      width: getHorizontalSize(
                                                          336),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.bottomLeft,
                                                      child: Container(
                                                          width:
                                                              getHorizontalSize(
                                                                  188),
                                                          margin: getMargin(
                                                              left: 24,
                                                              bottom: 26),
                                                          child: Text(
                                                              "Robotics Workshop",
                                                              maxLines: null,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterBlack36)))
                                                ])),
                                        Container(
                                            height: getVerticalSize(206),
                                            width: getHorizontalSize(336),
                                            margin: getMargin(top: 34),
                                            child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgRectangle51,
                                                      height:
                                                          getVerticalSize(206),
                                                      width: getHorizontalSize(
                                                          336),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.bottomLeft,
                                                      child: Container(
                                                          width:
                                                              getHorizontalSize(
                                                                  185),
                                                          margin: getMargin(
                                                              left: 29,
                                                              bottom: 19),
                                                          child: Text(
                                                              "Digital Marketing Bootcamp",
                                                              maxLines: null,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterBlack36)))
                                                ]))
                                      ])))
                        ])))),
            bottomNavigationBar: Container(
                margin: getMargin(left: 3),
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgGroup31),
                        fit: BoxFit.cover)),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: getHorizontalSize(387),
                              padding: getPadding(
                                  left: 33, top: 9, right: 33, bottom: 9),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image:
                                          AssetImage(ImageConstant.imgGroup240),
                                      fit: BoxFit.cover)),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                        svgPath: ImageConstant.imgVector,
                                        height: getSize(24),
                                        width: getSize(24),
                                        margin: getMargin(top: 35))
                                  ])))
                    ]))));
  }

  onTapViewmore(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentythreeScreen);
  }

  onTapTxtGroupNinetyOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtyfourScreen);
  }
}

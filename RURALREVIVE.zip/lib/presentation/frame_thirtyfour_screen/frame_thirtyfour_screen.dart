import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';

class FrameThirtyfourScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: double.maxFinite,
                        child: Stack(alignment: Alignment.topCenter, children: [
                          Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                  padding: getPadding(
                                      left: 85,
                                      top: 101,
                                      right: 85,
                                      bottom: 101),
                                  decoration: AppDecoration.fillTeal900,
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        CustomButton(
                                            height: getVerticalSize(49),
                                            text: "View More",
                                            margin: getMargin(top: 55),
                                            variant: ButtonVariant
                                                .OutlineBlack9003f_2,
                                            shape: ButtonShape.RoundedBorder16,
                                            padding: ButtonPadding.PaddingAll14,
                                            fontStyle:
                                                ButtonFontStyle.InterRegular17,
                                            onTap: () => onTapViewmore(context))
                                      ]))),
                          Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                  padding: getPadding(
                                      left: 21, top: 79, right: 21, bottom: 79),
                                  decoration: AppDecoration.fillWhiteA700
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder43),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                            height: getVerticalSize(47),
                                            width: getHorizontalSize(337),
                                            margin: getMargin(top: 15),
                                            child: Stack(
                                                alignment:
                                                    Alignment.centerRight,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: GestureDetector(
                                                          onTap: () {
                                                            onTapTxtGroupSeventeen(
                                                                context);
                                                          },
                                                          child: Container(
                                                              width:
                                                                  getHorizontalSize(
                                                                      179),
                                                              padding:
                                                                  getPadding(
                                                                      left: 30,
                                                                      top: 8,
                                                                      right: 39,
                                                                      bottom:
                                                                          8),
                                                              decoration: AppDecoration
                                                                  .txtFillGray300
                                                                  .copyWith(
                                                                      borderRadius:
                                                                          BorderRadiusStyle
                                                                              .txtRoundedBorder8),
                                                              child: Text("Recents",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtInterRegular21Black900)))),
                                                  CustomButton(
                                                      height:
                                                          getVerticalSize(47),
                                                      width: getHorizontalSize(
                                                          191),
                                                      text: "Upcomming",
                                                      variant: ButtonVariant
                                                          .FillCyan900,
                                                      fontStyle: ButtonFontStyle
                                                          .InterRegular21,
                                                      alignment:
                                                          Alignment.centerRight)
                                                ])),
                                        Container(
                                            height: getVerticalSize(206),
                                            width: getHorizontalSize(336),
                                            margin: getMargin(top: 30),
                                            child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgRectangle51206x336,
                                                      height:
                                                          getVerticalSize(206),
                                                      width: getHorizontalSize(
                                                          336),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.bottomLeft,
                                                      child: Container(
                                                          width:
                                                              getHorizontalSize(
                                                                  180),
                                                          margin: getMargin(
                                                              left: 29,
                                                              bottom: 26),
                                                          child: Text(
                                                              "Women in Tech Seminar",
                                                              maxLines: null,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterBlack36)))
                                                ])),
                                        Container(
                                            height: getVerticalSize(206),
                                            width: getHorizontalSize(336),
                                            margin: getMargin(top: 30),
                                            child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgRectangle50206x336,
                                                      height:
                                                          getVerticalSize(206),
                                                      width: getHorizontalSize(
                                                          336),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.bottomLeft,
                                                      child: Container(
                                                          width:
                                                              getHorizontalSize(
                                                                  245),
                                                          margin: getMargin(
                                                              left: 20,
                                                              bottom: 11),
                                                          child: Text(
                                                              "Introduction to Python Programming",
                                                              maxLines: null,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterBlack36)))
                                                ]))
                                      ])))
                        ])))),
            bottomNavigationBar: Container(
                margin: getMargin(left: 3),
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgGroup31),
                        fit: BoxFit.cover)),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: getHorizontalSize(387),
                              padding: getPadding(
                                  left: 33, top: 9, right: 33, bottom: 9),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image:
                                          AssetImage(ImageConstant.imgGroup240),
                                      fit: BoxFit.cover)),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                        svgPath: ImageConstant.imgVector,
                                        height: getSize(24),
                                        width: getSize(24),
                                        margin: getMargin(top: 35))
                                  ])))
                    ]))));
  }

  onTapViewmore(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentythreeScreen);
  }

  onTapTxtGroupSeventeen(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtythreeScreen);
  }
}

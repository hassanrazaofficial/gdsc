import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color black9003f = fromHex('#3f000000');

  static Color lightBlue800 = fromHex('#0276c9');

  static Color black900 = fromHex('#000000');

  static Color gray50001 = fromHex('#adabab');

  static Color teal900 = fromHex('#00343f');

  static Color lightBlueA700 = fromHex('#0495ff');

  static Color blueGray90002 = fromHex('#333232');

  static Color blueGray90001 = fromHex('#2e2d2d');

  static Color gray50002 = fromHex('#9c9797');

  static Color blueGray900 = fromHex('#363434');

  static Color teal90077 = fromHex('#77023e4b');

  static Color gray700 = fromHex('#676767');

  static Color gray400 = fromHex('#b0aeae');

  static Color blueGray100 = fromHex('#d9d9d9');

  static Color gray500 = fromHex('#ababab');

  static Color gray800 = fromHex('#383838');

  static Color orange800 = fromHex('#d96800');

  static Color orange700 = fromHex('#ff7a00');

  static Color lightBlue50 = fromHex('#e1f9ff');

  static Color gray100D1 = fromHex('#d1f3f3f3');

  static Color gray200 = fromHex('#f0f0f0');

  static Color gray300 = fromHex('#e3e2e1');

  static Color gray100 = fromHex('#f6f6f6');

  static Color cyan200 = fromHex('#85cddd');

  static Color gray40001 = fromHex('#c7c4c4');

  static Color gray20075 = fromHex('#75ecebeb');

  static Color gray40002 = fromHex('#bbbaba');

  static Color bluegray400 = fromHex('#888888');

  static Color gray40003 = fromHex('#b8b8b8');

  static Color cyan900 = fromHex('#006177');

  static Color whiteA700 = fromHex('#ffffff');

  static Color blueGray10082 = fromHex('#82d9d9d9');

  static Color gray300B2 = fromHex('#b2e3e2e1');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}

import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';

class FrameTwentyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 11, right: 11),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgArrowleft,
                          height: getVerticalSize(25),
                          width: getHorizontalSize(26),
                          margin: getMargin(left: 1, top: 21),
                          onTap: () {
                            onTapImgArrowleft(context);
                          }),
                      Padding(
                          padding: getPadding(left: 72, top: 33),
                          child: Text("Applicant Form",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold27)),
                      Container(
                          width: getHorizontalSize(356),
                          margin: getMargin(left: 4, top: 53, right: 7),
                          child: Text(
                              "Describe why you think this event is important for your community and how it will benefit the attendees:",
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium15)),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 5, top: 18, right: 5),
                          padding: getPadding(
                              left: 17, top: 15, right: 17, bottom: 15),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    width: getHorizontalSize(265),
                                    margin: getMargin(right: 58, bottom: 2),
                                    child: Text(
                                        "Main issues or challenges facing your community?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          margin: getMargin(left: 5, top: 19, right: 5),
                          padding: getPadding(
                              left: 17, top: 15, right: 17, bottom: 15),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    width: getHorizontalSize(321),
                                    margin: getMargin(bottom: 2),
                                    child: Text(
                                        "How will this event help address these issues \nor challenges?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 4, top: 19, right: 6),
                          padding: getPadding(
                              left: 17, top: 15, right: 17, bottom: 15),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    width: getHorizontalSize(266),
                                    margin: getMargin(right: 57, bottom: 2),
                                    child: Text(
                                        "Expected outcomes of the event (e.g. community building, Knowledge etc.)",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          width: getHorizontalSize(355),
                          margin: getMargin(left: 8, top: 32, right: 4),
                          child: Text(
                              "Describe the facilities and infrastructure available at the event location:",
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium15)),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 6, top: 19, right: 4),
                          padding: getPadding(all: 17),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                    padding: getPadding(bottom: 1),
                                    child: Text(
                                        "Venue or space is available for the event?",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtInterRegular15Bluegray90002))
                              ])),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 5, top: 19, right: 5),
                          padding: getPadding(
                              left: 17, top: 15, right: 17, bottom: 15),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    width: getHorizontalSize(316),
                                    margin: getMargin(right: 7),
                                    child: Text(
                                        "Are there any amenities or services available (e.g. electricity, internet access, restrooms, etc.)?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 5, top: 19, right: 5),
                          padding: getPadding(
                              left: 15, top: 16, right: 15, bottom: 16),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    width: getHorizontalSize(300),
                                    margin: getMargin(right: 27),
                                    child: Text(
                                        "Restrictions or imitations on the use of the space?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 10, top: 42),
                          child: Text(
                              "Describe any special requirements or equipment needed for the event:",
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium15)),
                      Container(
                          margin: getMargin(left: 8, top: 19, right: 2),
                          padding: getPadding(all: 17),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    width: getHorizontalSize(322),
                                    child: Text(
                                        "Equipment or resources are needed for the event (e.g. audiovisual equipment, tables and chairs, materials for workshops or presentations, etc.)?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          margin: getMargin(left: 10, top: 19),
                          padding: getPadding(left: 13, right: 13),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                    width: getHorizontalSize(328),
                                    margin: getMargin(top: 17),
                                    child: Text(
                                        "Any specific technical requirements or considerations (e.g. sound or lighting requirements, accessibility needs, etc.)?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      Container(
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 8, top: 19, right: 2),
                          padding: getPadding(
                              left: 15, top: 18, right: 15, bottom: 18),
                          decoration: AppDecoration.outlineGray5002.copyWith(
                              borderRadius: BorderRadiusStyle.circleBorder6),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    width: getHorizontalSize(322),
                                    margin: getMargin(right: 6, bottom: 14),
                                    child: Text(
                                        "How will these requirements be met or sourced (e.g. through the provider, through the community, etc.)?",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular15))
                              ])),
                      CustomButton(
                          height: getVerticalSize(49),
                          width: getHorizontalSize(169),
                          text: "Submit",
                          margin: getMargin(top: 58),
                          variant: ButtonVariant.OutlineBlack9003f,
                          shape: ButtonShape.RoundedBorder16,
                          fontStyle: ButtonFontStyle.InterRegular17,
                          onTap: () => onTapSubmit(context),
                          alignment: Alignment.center)
                    ]))));
  }

  onTapImgArrowleft(BuildContext context) {
    Navigator.pop(context);
  }

  onTapSubmit(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtyoneScreen);
  }
}

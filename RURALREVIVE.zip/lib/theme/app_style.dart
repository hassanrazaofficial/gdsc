import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';

class AppStyle {
  static TextStyle txtInterRegular15Bluegray90002 = TextStyle(
    color: ColorConstant.blueGray90002,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtSatisfyRegular61 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      61,
    ),
    fontFamily: 'Satisfy',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16Gray700 = TextStyle(
    color: ColorConstant.gray700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular19Lightblue800 = TextStyle(
    color: ColorConstant.lightBlue800,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular21 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtKarlaMedium16Bluegray90001 = TextStyle(
    color: ColorConstant.blueGray90001,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Karla',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterBold27 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      27,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold21 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold22 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      22,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold21Teal900 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterBold23 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterLight18 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w300,
  );

  static TextStyle txtInterBlack36 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      36,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w900,
  );

  static TextStyle txtInterBold20 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterSemiBold20Teal900 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtSatisfyRegular61Teal900 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      61,
    ),
    fontFamily: 'Satisfy',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium19Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtKarlaMedium16 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Karla',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium19 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular21Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      21,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium13 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterBold16 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterMedium16 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular15Black9001 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterSemiBold18 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtInterMedium14 = TextStyle(
    color: ColorConstant.gray800,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium15 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular19 = TextStyle(
    color: ColorConstant.lightBlue800,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium20 = TextStyle(
    color: ColorConstant.gray400,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium13Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterExtraBold23 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      23,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w800,
  );

  static TextStyle txtInterLight18Gray200 = TextStyle(
    color: ColorConstant.gray200,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w300,
  );

  static TextStyle txtInterSemiBold20 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtKarlaRegular16 = TextStyle(
    color: ColorConstant.lightBlueA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Karla',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15 = TextStyle(
    color: ColorConstant.blueGray90002,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16 = TextStyle(
    color: ColorConstant.blueGray90002,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular17 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanBold47 = TextStyle(
    color: ColorConstant.teal900,
    fontSize: getFontSize(
      47,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );
}

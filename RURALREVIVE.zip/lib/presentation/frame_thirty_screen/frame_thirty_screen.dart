import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';

class FrameThirtyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: double.maxFinite,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgArrowleft,
                          height: getVerticalSize(25),
                          width: getHorizontalSize(26),
                          margin: getMargin(left: 12, top: 21),
                          onTap: () {
                            onTapImgArrowleft(context);
                          }),
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle27,
                          height: getVerticalSize(117),
                          width: getHorizontalSize(351),
                          alignment: Alignment.center,
                          margin: getMargin(top: 4)),
                      Align(
                          alignment: Alignment.center,
                          child: Container(
                              height: getVerticalSize(534),
                              width: getHorizontalSize(358),
                              margin: getMargin(top: 10),
                              child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                            padding:
                                                getPadding(left: 7, right: 6),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Text(
                                                      "Educational Outreach Program",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterBold21),
                                                  Container(
                                                      width: getHorizontalSize(
                                                          333),
                                                      margin: getMargin(
                                                          left: 3,
                                                          top: 25,
                                                          right: 8),
                                                      child: RichText(
                                                          text: TextSpan(
                                                              children: [
                                                                TextSpan(
                                                                    text:
                                                                        "Date:",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .cyan900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                19),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w600)),
                                                                TextSpan(
                                                                    text: " ",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .black900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                19),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w500)),
                                                                TextSpan(
                                                                    text:
                                                                        "Ongoing\n",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .black900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                15),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w500)),
                                                                TextSpan(
                                                                    text: "",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .black900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                13),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w500)),
                                                                TextSpan(
                                                                    text:
                                                                        "Location:",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .cyan900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                19),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w600)),
                                                                TextSpan(
                                                                    text:
                                                                        " Various rural and remote areas of Pakistan Organizer: Developments in Literacy, supported by the United Nations Development Programme",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .black900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                15),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w500))
                                                              ]),
                                                          textAlign:
                                                              TextAlign.left)),
                                                  Container(
                                                      width: getHorizontalSize(
                                                          333),
                                                      margin: getMargin(
                                                          left: 3,
                                                          top: 6,
                                                          right: 8),
                                                      child: Text(
                                                          "Organizer: Developments in Literacy, supported by the United Nations Development Programme",
                                                          maxLines: null,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterMedium15)),
                                                  Container(
                                                      width: getHorizontalSize(
                                                          341),
                                                      margin: getMargin(
                                                          left: 3, top: 7),
                                                      child: RichText(
                                                          text: TextSpan(
                                                              children: [
                                                                TextSpan(
                                                                    text:
                                                                        "Description:",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .cyan900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                19),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w600)),
                                                                TextSpan(
                                                                    text: " ",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .cyan900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                15),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w500)),
                                                                TextSpan(
                                                                    text:
                                                                        "A long-term educational outreach program that provides academic support, mentorship, and training to students and educators in rural and remote areas of Pakistan. The program includes tutoring and mentorship for students, as well as professional development and training for teachers and administrators. The program also supports the establishment of libraries and computer labs in local schools and provides access to e-learning resources for students and educators",
                                                                    style: TextStyle(
                                                                        color: ColorConstant
                                                                            .black900,
                                                                        fontSize:
                                                                            getFontSize(
                                                                                15),
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontWeight:
                                                                            FontWeight.w500))
                                                              ]),
                                                          textAlign:
                                                              TextAlign.left)),
                                                  Padding(
                                                      padding: getPadding(
                                                          left: 3,
                                                          top: 9,
                                                          right: 3),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            GestureDetector(
                                                                onTap: () {
                                                                  onTapTxtSeemore(
                                                                      context);
                                                                },
                                                                child: Padding(
                                                                    padding: getPadding(
                                                                        top: 7,
                                                                        bottom:
                                                                            9),
                                                                    child: Text(
                                                                        "See more",
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtInterRegular19))),
                                                            GestureDetector(
                                                                onTap: () {
                                                                  onTapColumnapply(
                                                                      context);
                                                                },
                                                                child:
                                                                    Container(
                                                                        padding: getPadding(
                                                                            left:
                                                                                16,
                                                                            top:
                                                                                9,
                                                                            right:
                                                                                16,
                                                                            bottom:
                                                                                9),
                                                                        decoration: AppDecoration.outlineBlack9003f1.copyWith(
                                                                            borderRadius: BorderRadiusStyle
                                                                                .roundedBorder14),
                                                                        child: Column(
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            children: [
                                                                              Text("Apply", overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.txtInterRegular17)
                                                                            ])))
                                                          ]))
                                                ]))),
                                    Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                            height: getVerticalSize(534),
                                            width: getHorizontalSize(358),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        getHorizontalSize(23)),
                                                border: Border.all(
                                                    color:
                                                        ColorConstant.gray500,
                                                    width:
                                                        getHorizontalSize(1)))))
                                  ]))),
                      Container(
                          height: getVerticalSize(639),
                          width: getHorizontalSize(378),
                          margin: getMargin(left: 12, top: 27),
                          child:
                              Stack(alignment: Alignment.bottomLeft, children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      CustomImageView(
                                          imagePath: ImageConstant
                                              .imgRectangle27147x358,
                                          height: getVerticalSize(147),
                                          width: getHorizontalSize(358)),
                                      Container(
                                          width: getHorizontalSize(269),
                                          margin: getMargin(
                                              left: 4, top: 37, right: 84),
                                          child: Text(
                                              "Computer Literacy Program",
                                              maxLines: null,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterBold21Teal900)),
                                      Container(
                                          width: getHorizontalSize(330),
                                          margin: getMargin(
                                              left: 3, top: 21, right: 23),
                                          child: RichText(
                                              text: TextSpan(children: [
                                                TextSpan(
                                                    text: "Date:",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .cyan900,
                                                        fontSize:
                                                            getFontSize(19),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w600)),
                                                TextSpan(
                                                    text: " ",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black900,
                                                        fontSize:
                                                            getFontSize(19),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500)),
                                                TextSpan(
                                                    text: "June 15, 2023\n",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black900,
                                                        fontSize:
                                                            getFontSize(15),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500)),
                                                TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black900,
                                                        fontSize:
                                                            getFontSize(13),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500)),
                                                TextSpan(
                                                    text: "Location:",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .cyan900,
                                                        fontSize:
                                                            getFontSize(19),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w600)),
                                                TextSpan(
                                                    text: " ",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .cyan900,
                                                        fontSize:
                                                            getFontSize(15),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500)),
                                                TextSpan(
                                                    text:
                                                        "Village of Khushpur, district of Toba Tek Singh, Punjab\n\n",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black900,
                                                        fontSize:
                                                            getFontSize(15),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500)),
                                                TextSpan(
                                                    text: "Organizer:",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .cyan900,
                                                        fontSize:
                                                            getFontSize(19),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w600)),
                                                TextSpan(
                                                    text: " ",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .cyan900,
                                                        fontSize:
                                                            getFontSize(15),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500)),
                                                TextSpan(
                                                    text:
                                                        "Local NGO, supported by Microsoft Corporation",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black900,
                                                        fontSize:
                                                            getFontSize(15),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500))
                                              ]),
                                              textAlign: TextAlign.left)),
                                      Container(
                                          width: getHorizontalSize(337),
                                          margin: getMargin(
                                              left: 3, top: 21, right: 17),
                                          child: RichText(
                                              text: TextSpan(children: [
                                                TextSpan(
                                                    text: "Description:",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .cyan900,
                                                        fontSize:
                                                            getFontSize(19),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w600)),
                                                TextSpan(
                                                    text:
                                                        " A one-week computer literacy program for adults in the village of Khushpur, covering basic computer skills, such as typing, navigating the internet, and using Microsoft Office. The program will be conducted by trained volunteers from the local community, and participants will have access to computers and other necessary equipment. Lunch will be provided for all participants.",
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black900,
                                                        fontSize:
                                                            getFontSize(15),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500))
                                              ]),
                                              textAlign: TextAlign.left))
                                    ])),
                            Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                    height: getVerticalSize(475),
                                    width: getHorizontalSize(358),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(23)),
                                        border: Border.all(
                                            color: ColorConstant.gray500,
                                            width: getHorizontalSize(1))))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Padding(
                                    padding: getPadding(bottom: 19),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 8, bottom: 9),
                                              child: Text("See more",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular19Lightblue800)),
                                          GestureDetector(
                                              onTap: () {
                                                onTapStackrectanglethirty(
                                                    context);
                                              },
                                              child: Container(
                                                  height: getVerticalSize(40),
                                                  width: getHorizontalSize(153),
                                                  margin: getMargin(left: 129),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .centerRight,
                                                            child: Container(
                                                                height:
                                                                    getVerticalSize(
                                                                        40),
                                                                width:
                                                                    getHorizontalSize(
                                                                        81),
                                                                margin:
                                                                    getMargin(
                                                                        right:
                                                                            29),
                                                                decoration: BoxDecoration(
                                                                    color: ColorConstant
                                                                        .orange800,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            getHorizontalSize(16)),
                                                                    boxShadow: [
                                                                      BoxShadow(
                                                                          color: ColorConstant
                                                                              .black9003f,
                                                                          spreadRadius: getHorizontalSize(
                                                                              2),
                                                                          blurRadius: getHorizontalSize(
                                                                              2),
                                                                          offset: Offset(
                                                                              0,
                                                                              4))
                                                                    ]))),
                                                        Align(
                                                            alignment: Alignment
                                                                .topCenter,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 7),
                                                                child: Text(
                                                                    "Apply",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    style: AppStyle
                                                                        .txtInterRegular17WhiteA700)))
                                                      ])))
                                        ])))
                          ])),
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle271,
                          height: getVerticalSize(147),
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 10, top: 21)),
                      Container(
                          height: getVerticalSize(495),
                          width: getHorizontalSize(380),
                          margin: getMargin(left: 10, top: 25),
                          child:
                              Stack(alignment: Alignment.centerLeft, children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                    padding: getPadding(left: 10, top: 33),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text("STEM Education Workshops",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtInterBold20),
                                          Container(
                                              width: getHorizontalSize(339),
                                              margin:
                                                  getMargin(top: 21, right: 6),
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "Date:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "July 12-15, 2023\n",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(13),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "Location:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "Village of Kandiaro, district of Naushahro Feroze, Sindh\n\n",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "Organizer:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "University of Karachi, with support from Huawei Technologies",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ]),
                                                  textAlign: TextAlign.left)),
                                          Container(
                                              width: getHorizontalSize(346),
                                              margin: getMargin(top: 21),
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "Description:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "A series of STEM education workshops for students in the village of Kandiaro, focusing on robotics and coding. The workshops will be conducted by faculty and students from the University of Karachi, and participants will have the opportunity to work with advanced robotics kits and coding software. The workshops will culminate in a competition and showcase for participants and their families.",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ]),
                                                  textAlign: TextAlign.left))
                                        ]))),
                            Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                    height: getVerticalSize(495),
                                    width: getHorizontalSize(358),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(23)),
                                        border: Border.all(
                                            color: ColorConstant.gray500,
                                            width: getHorizontalSize(1))))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Padding(
                                    padding: getPadding(bottom: 26),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 8, bottom: 9),
                                              child: Text("See more",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular19Lightblue800)),
                                          GestureDetector(
                                              onTap: () {
                                                onTapStackrectanglethirtyone(
                                                    context);
                                              },
                                              child: Container(
                                                  height: getVerticalSize(40),
                                                  width: getHorizontalSize(153),
                                                  margin: getMargin(left: 129),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .centerRight,
                                                            child: Container(
                                                                height:
                                                                    getVerticalSize(
                                                                        40),
                                                                width:
                                                                    getHorizontalSize(
                                                                        81),
                                                                margin:
                                                                    getMargin(
                                                                        right:
                                                                            29),
                                                                decoration: BoxDecoration(
                                                                    color: ColorConstant
                                                                        .orange800,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            getHorizontalSize(16)),
                                                                    boxShadow: [
                                                                      BoxShadow(
                                                                          color: ColorConstant
                                                                              .black9003f,
                                                                          spreadRadius: getHorizontalSize(
                                                                              2),
                                                                          blurRadius: getHorizontalSize(
                                                                              2),
                                                                          offset: Offset(
                                                                              0,
                                                                              4))
                                                                    ]))),
                                                        Align(
                                                            alignment: Alignment
                                                                .topCenter,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 7),
                                                                child: Text(
                                                                    "Apply",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    style: AppStyle
                                                                        .txtInterRegular17WhiteA700)))
                                                      ])))
                                        ])))
                          ])),
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle28,
                          height: getVerticalSize(158),
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 8, top: 25)),
                      Container(
                          height: getVerticalSize(491),
                          width: getHorizontalSize(381),
                          margin: getMargin(left: 9, top: 31),
                          child:
                              Stack(alignment: Alignment.centerLeft, children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                    padding: getPadding(left: 13, top: 14),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text("Mobile Science Lab:",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterBold21Teal900),
                                          Container(
                                              width: getHorizontalSize(330),
                                              margin:
                                                  getMargin(top: 25, right: 6),
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "Date:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "August 23-27, 2023\n",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(13),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "Location:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text:
                                                            " Various rural and remote communities in Khyber Pakhtunkhwa\n\n",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "Organizer:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text:
                                                            " Science Education Foundation of Pakistan, supported by the World Bank",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ]),
                                                  textAlign: TextAlign.left)),
                                          Container(
                                              width: getHorizontalSize(337),
                                              margin: getMargin(top: 21),
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "Description:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "A mobile science lab that will travel to different rural and remote communities in Khyber Pakhtunkhwa, providing hands-on science activities and demonstrations for students and community members. The lab will be staffed by trained educators and will include equipment and materials for experiments in chemistry, physics, and biology. The program will also provide information on science careers and opportunities for further education.",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ]),
                                                  textAlign: TextAlign.left))
                                        ]))),
                            Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                    height: getVerticalSize(491),
                                    width: getHorizontalSize(358),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(23)),
                                        border: Border.all(
                                            color: ColorConstant.gray500,
                                            width: getHorizontalSize(1))))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Padding(
                                    padding: getPadding(bottom: 22),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 8, bottom: 9),
                                              child: Text("See more",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular19Lightblue800)),
                                          Container(
                                              height: getVerticalSize(40),
                                              width: getHorizontalSize(155),
                                              margin: getMargin(left: 129),
                                              child: Stack(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  children: [
                                                    Align(
                                                        alignment: Alignment
                                                            .centerRight,
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    40),
                                                            width:
                                                                getHorizontalSize(
                                                                    81),
                                                            margin: getMargin(
                                                                right: 31),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .orange800,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            getHorizontalSize(16)),
                                                                boxShadow: [
                                                                  BoxShadow(
                                                                      color: ColorConstant
                                                                          .black9003f,
                                                                      spreadRadius:
                                                                          getHorizontalSize(
                                                                              2),
                                                                      blurRadius:
                                                                          getHorizontalSize(
                                                                              2),
                                                                      offset:
                                                                          Offset(
                                                                              0,
                                                                              4))
                                                                ]))),
                                                    Align(
                                                        alignment:
                                                            Alignment.topCenter,
                                                        child: GestureDetector(
                                                            onTap: () {
                                                              onTapTxtApplyThree(
                                                                  context);
                                                            },
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 7),
                                                                child: Text(
                                                                    "Apply",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    style: AppStyle
                                                                        .txtInterRegular17WhiteA700))))
                                                  ]))
                                        ])))
                          ])),
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle29,
                          height: getVerticalSize(147),
                          width: getHorizontalSize(358),
                          margin: getMargin(left: 10, top: 38)),
                      Container(
                          height: getVerticalSize(553),
                          width: getHorizontalSize(381),
                          margin: getMargin(left: 9, top: 36),
                          child:
                              Stack(alignment: Alignment.centerLeft, children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                    padding: getPadding(left: 15, top: 15),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text("Coding Bootcamp:",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterBold21Teal900),
                                          Container(
                                              width: getHorizontalSize(330),
                                              margin:
                                                  getMargin(top: 25, right: 8),
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "Date:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text: " ",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text:
                                                            "September 6-30, 2023\n",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(13),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "Location:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text:
                                                            " Village of Thari Mirwah, district of Khairpur, Sindh\n\n",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500)),
                                                    TextSpan(
                                                        text: "Organizer:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text:
                                                            " National University of Computer and Emerging Sciences, with support from Google",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ]),
                                                  textAlign: TextAlign.left)),
                                          Container(
                                              width: getHorizontalSize(337),
                                              margin:
                                                  getMargin(left: 2, top: 25),
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "Description:",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .cyan900,
                                                            fontSize:
                                                                getFontSize(19),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600)),
                                                    TextSpan(
                                                        text:
                                                            " A month-long coding bootcamp for students and young adults in the village of Thari Mirwah, focusing on web development and programming languages such as Python and Java. The bootcamp will be conducted by faculty and alumni from the National University of Computer and Emerging Sciences, and participants will have access to computers and other necessary equipment. The bootcamp will conclude with a showcase of participants' projects and an opportunity for networking with local technology companies.",
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .black900,
                                                            fontSize:
                                                                getFontSize(15),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ]),
                                                  textAlign: TextAlign.left))
                                        ]))),
                            Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                    height: getVerticalSize(553),
                                    width: getHorizontalSize(358),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(23)),
                                        border: Border.all(
                                            color: ColorConstant.gray500,
                                            width: getHorizontalSize(1))))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Padding(
                                    padding: getPadding(bottom: 23),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 8, bottom: 9),
                                              child: Text("See more",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtInterRegular19Lightblue800)),
                                          GestureDetector(
                                              onTap: () {
                                                onTapStackrectanglethirtythree(
                                                    context);
                                              },
                                              child: Container(
                                                  height: getVerticalSize(40),
                                                  width: getHorizontalSize(155),
                                                  margin: getMargin(left: 129),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .centerRight,
                                                            child: Container(
                                                                height:
                                                                    getVerticalSize(
                                                                        40),
                                                                width:
                                                                    getHorizontalSize(
                                                                        81),
                                                                margin:
                                                                    getMargin(
                                                                        right:
                                                                            31),
                                                                decoration: BoxDecoration(
                                                                    color: ColorConstant
                                                                        .orange800,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            getHorizontalSize(16)),
                                                                    boxShadow: [
                                                                      BoxShadow(
                                                                          color: ColorConstant
                                                                              .black9003f,
                                                                          spreadRadius: getHorizontalSize(
                                                                              2),
                                                                          blurRadius: getHorizontalSize(
                                                                              2),
                                                                          offset: Offset(
                                                                              0,
                                                                              4))
                                                                    ]))),
                                                        Align(
                                                            alignment: Alignment
                                                                .topCenter,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 7),
                                                                child: Text(
                                                                    "Apply",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    style: AppStyle
                                                                        .txtInterRegular17WhiteA700)))
                                                      ])))
                                        ])))
                          ]))
                    ]))));
  }

  onTapImgArrowleft(BuildContext context) {
    Navigator.pop(context);
  }

  onTapTxtSeemore(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyfiveScreen);
  }

  onTapColumnapply(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }

  onTapStackrectanglethirty(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }

  onTapStackrectanglethirtyone(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }

  onTapTxtApplyThree(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }

  onTapStackrectanglethirtythree(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentyScreen);
  }
}

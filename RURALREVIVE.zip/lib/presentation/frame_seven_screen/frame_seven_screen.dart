import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class FrameSevenScreen extends StatelessWidget {
  TextEditingController group108Controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 16, top: 29, right: 16, bottom: 29),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                          padding: getPadding(top: 11),
                          child: Text("Manage Requests",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold27)),
                      Container(
                          height: getVerticalSize(635),
                          width: getHorizontalSize(358),
                          margin: getMargin(top: 27),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                    padding: getPadding(
                                        left: 13, top: 34, right: 16),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Container(
                                              height: getVerticalSize(51),
                                              width: getHorizontalSize(54),
                                              margin: getMargin(left: 8),
                                              child: Stack(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  children: [
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    51),
                                                            width:
                                                                getHorizontalSize(
                                                                    54),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .blueGray100,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            getHorizontalSize(27))))),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgSearch,
                                                        height:
                                                            getVerticalSize(23),
                                                        width:
                                                            getHorizontalSize(
                                                                20),
                                                        alignment:
                                                            Alignment.topCenter,
                                                        margin:
                                                            getMargin(top: 12))
                                                  ])),
                                          Container(
                                              height: getVerticalSize(184),
                                              width: getHorizontalSize(329),
                                              margin: getMargin(top: 16),
                                              decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.gray100D1,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              7)))),
                                          Padding(
                                              padding: getPadding(top: 54),
                                              child: SizedBox(
                                                  width: getHorizontalSize(217),
                                                  child: Divider(
                                                      height:
                                                          getVerticalSize(1),
                                                      thickness:
                                                          getVerticalSize(1),
                                                      color: ColorConstant
                                                          .gray40003,
                                                      indent: getHorizontalSize(
                                                          9)))),
                                          Padding(
                                              padding: getPadding(top: 46),
                                              child: SizedBox(
                                                  width: getHorizontalSize(217),
                                                  child: Divider(
                                                      height:
                                                          getVerticalSize(1),
                                                      thickness:
                                                          getVerticalSize(1),
                                                      color: ColorConstant
                                                          .gray40003,
                                                      indent: getHorizontalSize(
                                                          9))))
                                        ]))),
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    padding: getPadding(
                                        left: 13,
                                        top: 32,
                                        right: 13,
                                        bottom: 32),
                                    decoration: AppDecoration.outlineGray5001
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder14),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          GestureDetector(
                                              onTap: () {
                                                onTapTxtMilliebrown431(context);
                                              },
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 72, top: 6),
                                                  child: Text("MillieBrown431",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterSemiBold18))),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Text(
                                                  "MillieBrown431@email.com",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular15Bluegray90002)),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                  width: getHorizontalSize(307),
                                                  margin: getMargin(
                                                      left: 8,
                                                      top: 27,
                                                      right: 16),
                                                  child: RichText(
                                                      text: TextSpan(children: [
                                                        TextSpan(
                                                            text:
                                                                "The Cyber Security Summit is an event dedicated to educating individuals and businesses on the latest trends and best practices in cyber security. This year's summit will focus on topics such as data privacy, network security, and cyber threat intelligence. We will be featuring expert keynote ...",
                                                            style: TextStyle(
                                                                color: ColorConstant
                                                                    .blueGray90002,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400)),
                                                        TextSpan(
                                                            text: "See More",
                                                            style: TextStyle(
                                                                color: ColorConstant
                                                                    .lightBlue800,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500))
                                                      ]),
                                                      textAlign:
                                                          TextAlign.left))),
                                          Padding(
                                              padding:
                                                  getPadding(left: 9, top: 44),
                                              child: Text(
                                                  "Event Tittle: Cyber Security Summit",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular16Gray700)),
                                          Padding(
                                              padding:
                                                  getPadding(left: 8, top: 25),
                                              child: Text(
                                                  "Date of Event: April 1st, 2023",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular16Gray700)),
                                          Padding(
                                              padding:
                                                  getPadding(left: 8, top: 27),
                                              child: Text(
                                                  "Expected Number of Attendees: 100",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular16Gray700)),
                                          Padding(
                                              padding: getPadding(top: 12),
                                              child: SizedBox(
                                                  width: getHorizontalSize(217),
                                                  child: Divider(
                                                      height:
                                                          getVerticalSize(1),
                                                      thickness:
                                                          getVerticalSize(1),
                                                      color: ColorConstant
                                                          .gray40003,
                                                      indent: getHorizontalSize(
                                                          9)))),
                                          Padding(
                                              padding:
                                                  getPadding(left: 8, top: 12),
                                              child: Text(
                                                  "Estimated Budget: \$20,000",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular16Gray700)),
                                          CustomTextFormField(
                                              focusNode: FocusNode(),
                                              controller: group108Controller,
                                              hintText:
                                                  "Tech Event / 24 Offers Sent",
                                              margin:
                                                  getMargin(top: 17, right: 11),
                                              variant: TextFormFieldVariant
                                                  .OutlineGray500_1,
                                              shape: TextFormFieldShape
                                                  .RoundedBorder7,
                                              padding: TextFormFieldPadding
                                                  .PaddingAll12,
                                              fontStyle: TextFormFieldFontStyle
                                                  .InterRegular16,
                                              textInputAction:
                                                  TextInputAction.done),
                                          CustomButton(
                                              height: getVerticalSize(49),
                                              width: getHorizontalSize(215),
                                              text: "Connection Request",
                                              margin: getMargin(top: 25),
                                              variant: ButtonVariant
                                                  .OutlineBlack9003f,
                                              shape:
                                                  ButtonShape.RoundedBorder16,
                                              padding:
                                                  ButtonPadding.PaddingAll14,
                                              fontStyle: ButtonFontStyle
                                                  .InterRegular17,
                                              alignment: Alignment.center)
                                        ])))
                          ]))
                    ])),
            bottomNavigationBar: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: fs.Svg(ImageConstant.imgGroup30),
                        fit: BoxFit.cover)),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: double.maxFinite,
                              padding: getPadding(
                                  left: 33, top: 9, right: 33, bottom: 9),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: fs.Svg(ImageConstant.imgGroup30),
                                      fit: BoxFit.cover)),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                        svgPath: ImageConstant.imgEye,
                                        height: getSize(24),
                                        width: getSize(24),
                                        margin: getMargin(top: 35))
                                  ])))
                    ]))));
  }

  onTapTxtMilliebrown431(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtysixScreen);
  }
}

import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';

// ignore: must_be_immutable
class ListabItemWidget extends StatelessWidget {
  ListabItemWidget({this.onTapTxtComputerliteracOne, this.onTapApply});

  VoidCallback? onTapTxtComputerliteracOne;

  VoidCallback? onTapApply;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        padding: getPadding(
          left: 6,
          top: 11,
          right: 6,
          bottom: 11,
        ),
        decoration: AppDecoration.outlineGray500.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder23,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Expanded(
              child: Padding(
                padding: getPadding(
                  top: 2,
                  bottom: 1,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomButton(
                          height: getVerticalSize(
                            48,
                          ),
                          width: getHorizontalSize(
                            56,
                          ),
                          text: "AB",
                          margin: getMargin(
                            top: 1,
                            bottom: 4,
                          ),
                          variant: ButtonVariant.FillBluegray100,
                          shape: ButtonShape.Square,
                          fontStyle: ButtonFontStyle.InterMedium20,
                        ),
                        GestureDetector(
                          onTap: () {
                            onTapTxtComputerliteracOne?.call();
                          },
                          child: Container(
                            width: getHorizontalSize(
                              180,
                            ),
                            margin: getMargin(
                              left: 9,
                            ),
                            child: Text(
                              "Computer Literacy \nProgram",
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterSemiBold20,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      width: getHorizontalSize(
                        156,
                      ),
                      margin: getMargin(
                        right: 23,
                      ),
                      child: Text(
                        "Local NGO, supported by Microsoft Corporation",
                        maxLines: null,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterMedium13,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: getPadding(
                left: 3,
                top: 26,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      right: 8,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        CustomImageView(
                          svgPath: ImageConstant.imgVideocamera,
                          height: getSize(
                            16,
                          ),
                          width: getSize(
                            16,
                          ),
                        ),
                        CustomImageView(
                          svgPath: ImageConstant.imgFavorite,
                          height: getVerticalSize(
                            14,
                          ),
                          width: getHorizontalSize(
                            16,
                          ),
                          margin: getMargin(
                            left: 16,
                            top: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  CustomButton(
                    height: getVerticalSize(
                      40,
                    ),
                    width: getHorizontalSize(
                      81,
                    ),
                    text: "Apply",
                    margin: getMargin(
                      top: 11,
                    ),
                    variant: ButtonVariant.OutlineBlack9003f,
                    shape: ButtonShape.RoundedBorder16,
                    fontStyle: ButtonFontStyle.InterRegular17,
                    onTap: () => onTapApply(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ImageConstant {
  static String imgRectangle50 = 'assets/images/img_rectangle50.png';

  static String imgGroup30 = 'assets/images/img_group30.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgRectangle50206x336 =
      'assets/images/img_rectangle50_206x336.png';

  static String imgRectangle38 = 'assets/images/img_rectangle38.png';

  static String imgMapofworldon305x388 =
      'assets/images/img_mapofworldon_305x388.png';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgGroup152 = 'assets/images/img_group152.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgUserBlueGray700 = 'assets/images/img_user_blue_gray_700.svg';

  static String imgRectangle271 = 'assets/images/img_rectangle27_1.png';

  static String imgRectangle29 = 'assets/images/img_rectangle29.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgRectangle27147x358 =
      'assets/images/img_rectangle27_147x358.png';

  static String imgJshjwdremovebgpreview =
      'assets/images/img_jshjwdremovebgpreview.png';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgGroup28 = 'assets/images/img_group28.svg';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgRectangle27 = 'assets/images/img_rectangle27.png';

  static String imgMapofworldon731x375 =
      'assets/images/img_mapofworldon_731x375.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgGroup31 = 'assets/images/img_group31.png';

  static String imgRectangle28 = 'assets/images/img_rectangle28.png';

  static String imgGooglemapta1 = 'assets/images/img_googlemapta1.png';

  static String imgRectangle51 = 'assets/images/img_rectangle51.png';

  static String imgGroup240 = 'assets/images/img_group240.png';

  static String imgEvent20removebgpreview =
      'assets/images/img_event20removebgpreview.png';

  static String imgGoogle = 'assets/images/img_google.png';

  static String imgMapofworldon = 'assets/images/img_mapofworldon.png';

  static String imgRectangle51206x336 =
      'assets/images/img_rectangle51_206x336.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}

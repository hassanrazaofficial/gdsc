import '../frame_eleven_screen/widgets/listellipsefour_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:maryam_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class FrameElevenScreen extends StatelessWidget {
  TextEditingController groupTwentySevenController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            appBar: CustomAppBar(
                height: getVerticalSize(71),
                leadingWidth: 38,
                leading: AppbarImage(
                    height: getVerticalSize(25),
                    width: getHorizontalSize(26),
                    svgPath: ImageConstant.imgArrowleft,
                    margin: getMargin(left: 12, top: 15, bottom: 15),
                    onTap: () => onTapArrowleft1(context)),
                title: Padding(
                    padding: getPadding(left: 12),
                    child: Text("Inbox",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtInterBold27)),
                actions: [
                  AppbarImage(
                      height: getVerticalSize(24),
                      width: getHorizontalSize(27),
                      svgPath: ImageConstant.imgEdit,
                      margin:
                          getMargin(left: 19, top: 12, right: 19, bottom: 19))
                ]),
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: groupTwentySevenController,
                          hintText: "Search...",
                          margin: getMargin(left: 17, top: 26, right: 20),
                          variant: TextFormFieldVariant.FillGray100,
                          shape: TextFormFieldShape.RoundedBorder7,
                          padding: TextFormFieldPadding.PaddingAll12,
                          fontStyle:
                              TextFormFieldFontStyle.InterLight18Gray50001,
                          textInputAction: TextInputAction.done),
                      Padding(
                          padding: getPadding(left: 16, top: 36, right: 18),
                          child: ListView.separated(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              separatorBuilder: (context, index) {
                                return Padding(
                                    padding:
                                        getPadding(top: 22.5, bottom: 22.5),
                                    child: SizedBox(
                                        width: getHorizontalSize(299),
                                        child: Divider(
                                            height: getVerticalSize(1),
                                            thickness: getVerticalSize(1),
                                            color: ColorConstant.gray40003)));
                              },
                              itemCount: 6,
                              itemBuilder: (context, index) {
                                return ListellipsefourItemWidget();
                              })),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding: getPadding(top: 14),
                              child: Divider(
                                  height: getVerticalSize(1),
                                  thickness: getVerticalSize(1),
                                  color: ColorConstant.gray40003,
                                  indent: getHorizontalSize(70),
                                  endIndent: getHorizontalSize(21)))),
                      Container(
                          height: getVerticalSize(91),
                          width: getHorizontalSize(387),
                          margin: getMargin(top: 34),
                          child: Stack(alignment: Alignment.topLeft, children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                    height: getVerticalSize(51),
                                    width: getHorizontalSize(54),
                                    margin: getMargin(left: 18),
                                    child: Stack(
                                        alignment: Alignment.topCenter,
                                        children: [
                                          Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                  height: getVerticalSize(51),
                                                  width: getHorizontalSize(54),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .blueGray100,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  27))))),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgSearch,
                                              height: getVerticalSize(23),
                                              width: getHorizontalSize(20),
                                              alignment: Alignment.topCenter,
                                              margin: getMargin(top: 12))
                                        ]))),
                            Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                    padding: getPadding(left: 79, top: 2),
                                    child: Text("Annette_Black",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterSemiBold18))),
                            Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                    padding: getPadding(left: 79, top: 26),
                                    child: Text("Details are attached....",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtInterRegular15Bluegray90002))),
                            Align(
                                alignment: Alignment.topRight,
                                child: Padding(
                                    padding: getPadding(top: 1, right: 24),
                                    child: Text("Feb 9",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtInterRegular15Bluegray90002))),
                            Align(
                                alignment: Alignment.bottomRight,
                                child: SizedBox(
                                    width: getHorizontalSize(314),
                                    child: Divider(
                                        height: getVerticalSize(1),
                                        thickness: getVerticalSize(1),
                                        color: ColorConstant.gray40003,
                                        endIndent: getHorizontalSize(15)))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                                ImageConstant.imgGroup31),
                                            fit: BoxFit.cover)),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Container(
                                              width: double.maxFinite,
                                              child: Container(
                                                  width: getHorizontalSize(387),
                                                  padding: getPadding(
                                                      left: 33,
                                                      top: 9,
                                                      right: 33,
                                                      bottom: 9),
                                                  decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              ImageConstant
                                                                  .imgGroup152),
                                                          fit: BoxFit.cover)),
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgVector,
                                                            height: getSize(24),
                                                            width: getSize(24),
                                                            margin: getMargin(
                                                                top: 35))
                                                      ])))
                                        ])))
                          ]))
                    ]))));
  }

  onTapArrowleft1(BuildContext context) {
    Navigator.pop(context);
  }
}

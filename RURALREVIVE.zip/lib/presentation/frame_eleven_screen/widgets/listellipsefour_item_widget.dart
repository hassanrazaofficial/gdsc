import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';

// ignore: must_be_immutable
class ListellipsefourItemWidget extends StatelessWidget {
  ListellipsefourItemWidget();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: getVerticalSize(
            51,
          ),
          width: getHorizontalSize(
            54,
          ),
          child: Stack(
            alignment: Alignment.topCenter,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: getVerticalSize(
                    51,
                  ),
                  width: getHorizontalSize(
                    54,
                  ),
                  decoration: BoxDecoration(
                    color: ColorConstant.blueGray100,
                    borderRadius: BorderRadius.circular(
                      getHorizontalSize(
                        27,
                      ),
                    ),
                  ),
                ),
              ),
              CustomImageView(
                svgPath: ImageConstant.imgSearch,
                height: getVerticalSize(
                  23,
                ),
                width: getHorizontalSize(
                  20,
                ),
                alignment: Alignment.topCenter,
                margin: getMargin(
                  top: 12,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: getPadding(
            top: 1,
            bottom: 4,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    "MillieBrown431",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtInterSemiBold18,
                  ),
                  Padding(
                    padding: getPadding(
                      left: 111,
                      bottom: 3,
                    ),
                    child: Text(
                      "Mar 21",
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular15Bluegray90002,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: getPadding(
                  top: 3,
                ),
                child: Text(
                  "Hello..!!",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtInterRegular15Bluegray90002,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';

class FrameFortyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: double.maxFinite,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgGooglemapta1,
                height: getVerticalSize(
                  844,
                ),
                width: getHorizontalSize(
                  390,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

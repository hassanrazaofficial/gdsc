import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';

class FrameThirtyfiveScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: SizedBox(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: double.maxFinite,
                        child: Stack(alignment: Alignment.topCenter, children: [
                          Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                  padding: getPadding(
                                      left: 85, top: 99, right: 85, bottom: 99),
                                  decoration: AppDecoration.fillTeal900,
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        CustomButton(
                                            height: getVerticalSize(49),
                                            text: "Add More",
                                            margin: getMargin(top: 59),
                                            variant: ButtonVariant
                                                .OutlineBlack9003f_2,
                                            shape: ButtonShape.RoundedBorder16,
                                            padding: ButtonPadding.PaddingAll14,
                                            fontStyle:
                                                ButtonFontStyle.InterRegular17,
                                            onTap: () => onTapAddmore(context))
                                      ]))),
                          Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                  padding: getPadding(
                                      left: 27, top: 95, right: 27, bottom: 95),
                                  decoration: AppDecoration.fillWhiteA700
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder43),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        CustomButton(
                                            height: getVerticalSize(47),
                                            width: getHorizontalSize(191),
                                            text: "Saved",
                                            margin: getMargin(left: 67),
                                            variant: ButtonVariant.FillCyan900,
                                            fontStyle:
                                                ButtonFontStyle.InterRegular21),
                                        Container(
                                            height: getVerticalSize(206),
                                            width: getHorizontalSize(336),
                                            margin:
                                                getMargin(top: 34, bottom: 215),
                                            child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgRectangle51206x336,
                                                      height:
                                                          getVerticalSize(206),
                                                      width: getHorizontalSize(
                                                          336),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.bottomLeft,
                                                      child: Container(
                                                          width: getSize(146),
                                                          margin: getMargin(
                                                              left: 23,
                                                              bottom: 12),
                                                          child: Text(
                                                              "Mobile\nScience\nLab",
                                                              maxLines: null,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtInterBlack36)))
                                                ]))
                                      ])))
                        ])))),
            bottomNavigationBar: Container(
                margin: getMargin(left: 3),
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgGroup31),
                        fit: BoxFit.cover)),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: getHorizontalSize(387),
                              padding: getPadding(
                                  left: 33, top: 9, right: 33, bottom: 9),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image:
                                          AssetImage(ImageConstant.imgGroup240),
                                      fit: BoxFit.cover)),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                        svgPath: ImageConstant.imgVector,
                                        height: getSize(24),
                                        width: getSize(24),
                                        margin: getMargin(top: 35))
                                  ])))
                    ]))));
  }

  onTapAddmore(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentythreeScreen);
  }
}

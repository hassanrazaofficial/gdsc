import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_icon_button.dart';

class FrameTwelveScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: double.maxFinite,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          padding: getPadding(
                              left: 25, top: 67, right: 25, bottom: 67),
                          decoration: AppDecoration.gradientTeal900Teal90077,
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                CustomIconButton(
                                    height: 64,
                                    width: 64,
                                    margin: getMargin(top: 27),
                                    child: CustomImageView(
                                        svgPath:
                                            ImageConstant.imgUserBlueGray700)),
                                Padding(
                                    padding: getPadding(
                                        left: 10, top: 34, bottom: 1),
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                              padding: getPadding(left: 1),
                                              child: Text("Charlotte James",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterExtraBold23)),
                                          Padding(
                                              padding: getPadding(top: 4),
                                              child: Row(children: [
                                                CustomImageView(
                                                    svgPath:
                                                        ImageConstant.imgTicket,
                                                    height: getSize(18),
                                                    width: getSize(18),
                                                    margin: getMargin(
                                                        top: 1, bottom: 2)),
                                                Padding(
                                                    padding:
                                                        getPadding(left: 8),
                                                    child: Text("Edit",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtInterLight18Gray200))
                                              ]))
                                        ]))
                              ])),
                      Padding(
                          padding: getPadding(left: 43, top: 47),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgVolume,
                                    height: getVerticalSize(30),
                                    width: getHorizontalSize(43),
                                    margin: getMargin(bottom: 2)),
                                Padding(
                                    padding: getPadding(left: 14, top: 6),
                                    child: Text("My Contact Info",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular21Black900))
                              ])),
                      Padding(
                          padding: getPadding(left: 52, top: 29),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgSettings,
                                    height: getSize(35),
                                    width: getSize(35),
                                    margin: getMargin(bottom: 1)),
                                Padding(
                                    padding: getPadding(left: 15, top: 10),
                                    child: Text("Settings",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtInterRegular21Black900))
                              ])),
                      GestureDetector(
                          onTap: () {
                            onTapRowevent20removebg(context);
                          },
                          child: Padding(
                              padding: getPadding(left: 49, top: 26),
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant
                                            .imgEvent20removebgpreview,
                                        height: getSize(35),
                                        width: getSize(35),
                                        margin: getMargin(bottom: 1)),
                                    Padding(
                                        padding: getPadding(left: 16, top: 10),
                                        child: Text("Highlights",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterRegular21Black900))
                                  ]))),
                      Align(
                          alignment: Alignment.center,
                          child: Padding(
                              padding: getPadding(top: 32),
                              child: Divider(
                                  height: getVerticalSize(2),
                                  thickness: getVerticalSize(2),
                                  color: ColorConstant.gray40003,
                                  indent: getHorizontalSize(23),
                                  endIndent: getHorizontalSize(30)))),
                      Padding(
                          padding: getPadding(left: 55, top: 35, bottom: 5),
                          child: Row(children: [
                            CustomImageView(
                                svgPath: ImageConstant.imgArrowright,
                                height: getSize(35),
                                width: getSize(35)),
                            Padding(
                                padding: getPadding(left: 15, top: 8),
                                child: Text("Log Out",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular21Black900))
                          ]))
                    ])),
            bottomNavigationBar: Container(
                margin: getMargin(left: 3),
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgGroup31),
                        fit: BoxFit.cover)),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: getHorizontalSize(387),
                              padding: getPadding(
                                  left: 33, top: 9, right: 33, bottom: 9),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image:
                                          AssetImage(ImageConstant.imgGroup240),
                                      fit: BoxFit.cover)),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomImageView(
                                        svgPath: ImageConstant.imgVector,
                                        height: getSize(24),
                                        width: getSize(24),
                                        margin: getMargin(top: 35),
                                        onTap: () {
                                          onTapImgVector(context);
                                        })
                                  ])))
                    ]))));
  }

  onTapRowevent20removebg(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtythreeScreen);
  }

  onTapImgVector(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameTwentythreeScreen);
  }
}

import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';

class FrameTwentyeightScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.teal900,
        body: Container(
          height: size.height,
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgMapofworldon731x375,
                height: getVerticalSize(
                  731,
                ),
                width: getHorizontalSize(
                  375,
                ),
                alignment: Alignment.bottomLeft,
                margin: getMargin(
                  bottom: 20,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  width: double.maxFinite,
                  child: Text(
                    "Rural Revive",
                    maxLines: null,
                    textAlign: TextAlign.center,
                    style: AppStyle.txtSatisfyRegular61,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

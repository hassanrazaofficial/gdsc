import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/core/utils/validation_functions.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FrameEightScreen extends StatelessWidget {
  TextEditingController group100Controller = TextEditingController();

  TextEditingController groupNinetySevenController = TextEditingController();

  TextEditingController groupNinetySixController = TextEditingController();

  TextEditingController groupNinetyFiveController = TextEditingController();

  TextEditingController groupNinetyNineController = TextEditingController();

  TextEditingController groupNinetyEightController = TextEditingController();

  TextEditingController group107Controller = TextEditingController();

  TextEditingController group105Controller = TextEditingController();

  TextEditingController group104Controller = TextEditingController();

  TextEditingController group103Controller = TextEditingController();

  TextEditingController group102Controller = TextEditingController();

  TextEditingController group106Controller = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 15, right: 15),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Align(
                              alignment: Alignment.center,
                              child: Padding(
                                  padding: getPadding(top: 53),
                                  child: Text("Event Request",
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold27))),
                          Padding(
                              padding: getPadding(left: 1, top: 21),
                              child: Text("Event Details",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium19)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group100Controller,
                              hintText: "Event Tittle",
                              margin: getMargin(top: 18)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: groupNinetySevenController,
                              hintText: "Event Type/Category",
                              margin: getMargin(left: 1, top: 20)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: groupNinetySixController,
                              hintText: "Date of Event",
                              margin: getMargin(top: 20)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: groupNinetyFiveController,
                              hintText: "Event Description",
                              margin: getMargin(top: 20),
                              padding: TextFormFieldPadding.PaddingT56,
                              maxLines: 6),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: groupNinetyNineController,
                              hintText: "Event Location",
                              margin: getMargin(top: 20)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: groupNinetyEightController,
                              hintText: "Expected Number of Attendees",
                              margin: getMargin(top: 20),
                              textInputType: TextInputType.number),
                          Padding(
                              padding: getPadding(left: 2, top: 36),
                              child: Text("Organizer Information",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium19)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group107Controller,
                              hintText: "Organizer Name",
                              margin: getMargin(left: 1, top: 17)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group105Controller,
                              hintText: "Organization Name(if applicable)",
                              margin: getMargin(left: 2, top: 20)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group104Controller,
                              hintText: "Email",
                              margin: getMargin(left: 1, top: 20),
                              textInputType: TextInputType.emailAddress),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group103Controller,
                              hintText: "Phone Number",
                              margin: getMargin(left: 1, top: 20),
                              textInputType: TextInputType.phone),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group102Controller,
                              hintText: "Website(if applicable)",
                              margin: getMargin(left: 1, top: 20)),
                          Padding(
                              padding: getPadding(left: 3, top: 44),
                              child: Text("Budget",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium19Black900)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: group106Controller,
                              hintText: "Estimated Budget",
                              margin: getMargin(left: 2, top: 17),
                              textInputAction: TextInputAction.done),
                          CustomButton(
                              height: getVerticalSize(49),
                              width: getHorizontalSize(169),
                              text: "Submit Request",
                              margin: getMargin(top: 52),
                              variant: ButtonVariant.OutlineBlack9003f,
                              shape: ButtonShape.RoundedBorder16,
                              fontStyle: ButtonFontStyle.InterRegular17,
                              onTap: () => onTapSubmitrequest(context),
                              alignment: Alignment.center)
                        ])))));
  }

  onTapSubmitrequest(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameThirtytwoScreen);
  }
}

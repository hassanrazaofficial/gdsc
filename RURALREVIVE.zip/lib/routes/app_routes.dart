import 'package:flutter/material.dart';
import 'package:maryam_s_application1/presentation/frame_twentythree_screen/frame_twentythree_screen.dart';
import 'package:maryam_s_application1/presentation/frame_twentyeight_screen/frame_twentyeight_screen.dart';
import 'package:maryam_s_application1/presentation/frame_five_screen/frame_five_screen.dart';
import 'package:maryam_s_application1/presentation/frame_fifteen_screen/frame_fifteen_screen.dart';
import 'package:maryam_s_application1/presentation/frame_fourteen_screen/frame_fourteen_screen.dart';
import 'package:maryam_s_application1/presentation/frame_seventeen_screen/frame_seventeen_screen.dart';
import 'package:maryam_s_application1/presentation/frame_eighteen_screen/frame_eighteen_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirty_screen/frame_thirty_screen.dart';
import 'package:maryam_s_application1/presentation/frame_twenty_screen/frame_twenty_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtyone_screen/frame_thirtyone_screen.dart';
import 'package:maryam_s_application1/presentation/frame_eight_screen/frame_eight_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtytwo_screen/frame_thirtytwo_screen.dart';
import 'package:maryam_s_application1/presentation/frame_twentyfive_screen/frame_twentyfive_screen.dart';
import 'package:maryam_s_application1/presentation/frame_twelve_screen/frame_twelve_screen.dart';
import 'package:maryam_s_application1/presentation/frame_forty_screen/frame_forty_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtythree_screen/frame_thirtythree_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtyfour_screen/frame_thirtyfour_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtyfive_screen/frame_thirtyfive_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtyseven_screen/frame_thirtyseven_screen.dart';
import 'package:maryam_s_application1/presentation/frame_sixteen_screen/frame_sixteen_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtyeight_screen/frame_thirtyeight_screen.dart';
import 'package:maryam_s_application1/presentation/frame_seven_screen/frame_seven_screen.dart';
import 'package:maryam_s_application1/presentation/frame_eleven_screen/frame_eleven_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtysix_screen/frame_thirtysix_screen.dart';
import 'package:maryam_s_application1/presentation/frame_thirtynine_screen/frame_thirtynine_screen.dart';
import 'package:maryam_s_application1/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String frameTwentythreeScreen = '/frame_twentythree_screen';

  static const String frameTwentyeightScreen = '/frame_twentyeight_screen';

  static const String frameFiveScreen = '/frame_five_screen';

  static const String frameFifteenScreen = '/frame_fifteen_screen';

  static const String frameFourteenScreen = '/frame_fourteen_screen';

  static const String frameSeventeenScreen = '/frame_seventeen_screen';

  static const String frameEighteenScreen = '/frame_eighteen_screen';

  static const String frameThirtyScreen = '/frame_thirty_screen';

  static const String frameTwentyScreen = '/frame_twenty_screen';

  static const String frameThirtyoneScreen = '/frame_thirtyone_screen';

  static const String frameEightScreen = '/frame_eight_screen';

  static const String frameThirtytwoScreen = '/frame_thirtytwo_screen';

  static const String frameTwentyfiveScreen = '/frame_twentyfive_screen';

  static const String frameTwelveScreen = '/frame_twelve_screen';

  static const String frameFortyScreen = '/frame_forty_screen';

  static const String frameThirtythreeScreen = '/frame_thirtythree_screen';

  static const String frameThirtyfourScreen = '/frame_thirtyfour_screen';

  static const String frameThirtyfiveScreen = '/frame_thirtyfive_screen';

  static const String frameThirtysevenScreen = '/frame_thirtyseven_screen';

  static const String frameSixteenScreen = '/frame_sixteen_screen';

  static const String frameThirtyeightScreen = '/frame_thirtyeight_screen';

  static const String frameSevenScreen = '/frame_seven_screen';

  static const String frameElevenScreen = '/frame_eleven_screen';

  static const String frameThirtysixScreen = '/frame_thirtysix_screen';

  static const String frameThirtynineScreen = '/frame_thirtynine_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    frameTwentythreeScreen: (context) => FrameTwentythreeScreen(),
    frameTwentyeightScreen: (context) => FrameTwentyeightScreen(),
    frameFiveScreen: (context) => FrameFiveScreen(),
    frameFifteenScreen: (context) => FrameFifteenScreen(),
    frameFourteenScreen: (context) => FrameFourteenScreen(),
    frameSeventeenScreen: (context) => FrameSeventeenScreen(),
    frameEighteenScreen: (context) => FrameEighteenScreen(),
    frameThirtyScreen: (context) => FrameThirtyScreen(),
    frameTwentyScreen: (context) => FrameTwentyScreen(),
    frameThirtyoneScreen: (context) => FrameThirtyoneScreen(),
    frameEightScreen: (context) => FrameEightScreen(),
    frameThirtytwoScreen: (context) => FrameThirtytwoScreen(),
    frameTwentyfiveScreen: (context) => FrameTwentyfiveScreen(),
    frameTwelveScreen: (context) => FrameTwelveScreen(),
    frameFortyScreen: (context) => FrameFortyScreen(),
    frameThirtythreeScreen: (context) => FrameThirtythreeScreen(),
    frameThirtyfourScreen: (context) => FrameThirtyfourScreen(),
    frameThirtyfiveScreen: (context) => FrameThirtyfiveScreen(),
    frameThirtysevenScreen: (context) => FrameThirtysevenScreen(),
    frameSixteenScreen: (context) => FrameSixteenScreen(),
    frameThirtyeightScreen: (context) => FrameThirtyeightScreen(),
    frameSevenScreen: (context) => FrameSevenScreen(),
    frameElevenScreen: (context) => FrameElevenScreen(),
    frameThirtysixScreen: (context) => FrameThirtysixScreen(),
    frameThirtynineScreen: (context) => FrameThirtynineScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}

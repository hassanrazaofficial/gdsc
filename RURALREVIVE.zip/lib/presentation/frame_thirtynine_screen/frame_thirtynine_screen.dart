import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/core/utils/validation_functions.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FrameThirtynineScreen extends StatelessWidget {
  TextEditingController nameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController phonenumberController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController confirmpasswordOneController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 15, right: 15),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                              padding: getPadding(top: 5),
                              child: Text("Personal Information",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold27)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: nameController,
                              hintText: "Full Name",
                              margin: getMargin(top: 67)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: emailController,
                              hintText: "Email",
                              margin: getMargin(top: 20),
                              textInputType: TextInputType.emailAddress),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: phonenumberController,
                              hintText: "Phone Number",
                              margin: getMargin(top: 20),
                              textInputType: TextInputType.phone),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: passwordController,
                              hintText: "Password",
                              margin: getMargin(top: 20),
                              textInputType: TextInputType.visiblePassword,
                              isObscureText: true),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: confirmpasswordOneController,
                              hintText: "Confirm Password",
                              margin: getMargin(top: 20),
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              isObscureText: true),
                          Spacer(),
                          Padding(
                              padding: getPadding(left: 9, right: 19),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomButton(
                                        height: getVerticalSize(36),
                                        width: getHorizontalSize(70),
                                        text: "Back",
                                        padding: ButtonPadding.PaddingAll8,
                                        onTap: () => onTapBack(context)),
                                    CustomButton(
                                        height: getVerticalSize(36),
                                        width: getHorizontalSize(70),
                                        text: "Next",
                                        padding: ButtonPadding.PaddingAll8,
                                        onTap: () => onTapNext(context))
                                  ])),
                          Container(
                              width: getHorizontalSize(220),
                              margin: getMargin(left: 70, top: 43, right: 70),
                              padding: getPadding(left: 3, right: 3),
                              decoration: AppDecoration.fillBluegray100
                                  .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.circleBorder6),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                        height: getVerticalSize(12),
                                        width: getHorizontalSize(61),
                                        decoration: BoxDecoration(
                                            color: ColorConstant.cyan900,
                                            borderRadius: BorderRadius.circular(
                                                getHorizontalSize(6))))
                                  ]))
                        ])))));
  }

  onTapBack(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameFifteenScreen);
  }

  onTapNext(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameSixteenScreen);
  }
}

import 'package:flutter/material.dart';
import 'package:maryam_s_application1/core/app_export.dart';
import 'package:maryam_s_application1/widgets/custom_button.dart';
import 'package:maryam_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FrameSeventeenScreen extends StatelessWidget {
  TextEditingController addressController = TextEditingController();

  TextEditingController agerangeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 15, right: 15),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(left: 26, top: 5),
                              child: Text("Additional Information",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold27))),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: addressController,
                          hintText: "Address",
                          margin: getMargin(top: 68)),
                      CustomButton(
                          height: getVerticalSize(55),
                          text:
                              "Type of events you are interested in attending",
                          margin: getMargin(top: 20),
                          variant: ButtonVariant.OutlineGray500,
                          shape: ButtonShape.RoundedBorder4,
                          padding: ButtonPadding.PaddingT18),
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: getHorizontalSize(358),
                              margin: getMargin(left: 1, top: 20, right: 1),
                              padding: getPadding(
                                  left: 17, top: 15, right: 17, bottom: 15),
                              decoration: AppDecoration.outlineGray5002
                                  .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.circleBorder6),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                        width: getHorizontalSize(265),
                                        margin: getMargin(right: 58, bottom: 2),
                                        child: Text(
                                            "Locations where you are interested in attending events",
                                            maxLines: null,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular15))
                                  ]))),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: agerangeController,
                          hintText:
                              "Age range of attendees you are looking for",
                          margin: getMargin(top: 20),
                          textInputAction: TextInputAction.done),
                      Container(
                          width: double.maxFinite,
                          child: Container(
                              width: getHorizontalSize(358),
                              margin: getMargin(left: 1, top: 20, right: 1),
                              padding: getPadding(
                                  left: 17, top: 15, right: 17, bottom: 15),
                              decoration: AppDecoration.outlineGray5002
                                  .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.circleBorder6),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                        width: getHorizontalSize(306),
                                        margin: getMargin(right: 17, bottom: 5),
                                        child: Text(
                                            "Special needs or accommodations required for attendees",
                                            maxLines: null,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular15))
                                  ]))),
                      Spacer(),
                      Container(
                          height: getVerticalSize(36),
                          width: getHorizontalSize(332),
                          child:
                              Stack(alignment: Alignment.centerLeft, children: [
                            Align(
                                alignment: Alignment.centerRight,
                                child: GestureDetector(
                                    onTap: () {
                                      onTapColumnnext(context);
                                    },
                                    child: Container(
                                        padding: getPadding(
                                            left: 17,
                                            top: 8,
                                            right: 17,
                                            bottom: 8),
                                        decoration: AppDecoration
                                            .outlineBlack9003f
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .circleBorder6),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text("Next",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterRegular15Bluegray90002)
                                            ])))),
                            Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                    padding: getPadding(
                                        left: 16, top: 8, right: 16, bottom: 8),
                                    decoration: AppDecoration.outlineBlack9003f
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .circleBorder6),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text("Back",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtInterRegular15Bluegray90002)
                                        ]))),
                            Align(
                                alignment: Alignment.center,
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomButton(
                                          height: getVerticalSize(36),
                                          width: getHorizontalSize(70),
                                          text: "Back",
                                          padding: ButtonPadding.PaddingAll8),
                                      CustomButton(
                                          height: getVerticalSize(36),
                                          width: getHorizontalSize(70),
                                          text: "Next",
                                          padding: ButtonPadding.PaddingAll8)
                                    ]))
                          ])),
                      Container(
                          height: getVerticalSize(13),
                          width: getHorizontalSize(220),
                          margin: getMargin(top: 42),
                          child: Stack(alignment: Alignment.topLeft, children: [
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                    height: getVerticalSize(12),
                                    width: getHorizontalSize(220),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100,
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(6))))),
                            Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                    height: getVerticalSize(12),
                                    width: getHorizontalSize(111),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.cyan900,
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(6)))))
                          ]))
                    ]))));
  }

  onTapColumnnext(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.frameEighteenScreen);
  }
}
